import { NextResponse } from 'next/server';
import { hash, verify } from '@node-rs/argon2';
import crypto from 'crypto';
import { sql } from '@/lib/db';
import { sha, ip, limit, startSession, currentUser, endSession, recoveryCode } from '@/lib/auth';
import { putUrl, getUrl, head, remove } from '@/lib/s3';

const MAX = Number(process.env.MAX_FILE_MB || 2000) * 1048576;
const OK = { mp4:'video/mp4', webm:'video/webm', mov:'video/quicktime', mkv:'video/x-matroska',
  mp3:'audio/mpeg', wav:'audio/wav', m4a:'audio/mp4', aac:'audio/aac', ogg:'audio/ogg' };
const J = (d, s = 200) => NextResponse.json(d, { status: s });
const E = (m, s = 400) => J({ error: m }, s);

export async function POST(req, { params }) {
  const a = (await params).a[0];
  const o = req.headers.get('origin');
  if (!o || new URL(o).host !== req.headers.get('host')) return E('Bad origin', 403);
  const b = await req.json().catch(() => ({}));
  const I = await ip();
  try {
    if (a === 'register') {
      if (!(await limit('reg:' + I, 5, 3600))) return E('Too many attempts. Try later.', 429);
      const u = String(b.u || '').toLowerCase(), p = String(b.p || '');
      if (!/^[a-z0-9_]{3,24}$/.test(u)) return E('Username: 3-24 letters, numbers or _');
      if (p.length < 8 || p.length > 200) return E('Password must be at least 8 characters.');
      const code = recoveryCode();
      try {
        const r = await sql`insert into users(username,pw_hash,recovery_hash) values(${u},${await hash(p, { algorithm: 2 })},${sha(code)}) returning id`;
        await startSession(r[0].id);
        return J({ code });
      } catch (e) { if (e.code === '23505') return E('Username already taken.', 409); throw e; }
    }
    if (a === 'login') {
      const u = String(b.u || '').toLowerCase();
      if (!(await limit('login:' + I + u, 8, 900))) return E('Too many attempts. Try in 15 minutes.', 429);
      const r = (await sql`select id,pw_hash from users where username=${u}`)[0];
      const good = r && await verify(r.pw_hash, String(b.p || '')).catch(() => false);
      if (!good) return E('Incorrect username or password.', 401);
      await startSession(r.id); return J({ ok: 1 });
    }
    if (a === 'lookup') {
      if (!(await limit('rec:' + I, 10, 900))) return E('Too many attempts.', 429);
      const c = String(b.code || '').toUpperCase().replace(/\s/g, '');
      const r = (await sql`select username from users where recovery_hash=${sha(c)}`)[0];
      return r ? J({ username: r.username }) : E('Recovery code not found.', 404);
    }
    if (a === 'logout') { await endSession(); return J({ ok: 1 }); }

    const user = await currentUser();
    if (!user) return E('Your session has expired. Please log in again.', 401);

    if (a === 'list') {
      const q = '%' + String(b.q || '').replace(/[%_\\]/g, '\\$&') + '%';
      const r = await sql`select id,name,mime,size,created_at from files where user_id=${user.id} and status='ready' and name ilike ${q}`;
      const t = x => new Date(x.created_at).getTime();
      const s = { new: (x, y) => t(y) - t(x), old: (x, y) => t(x) - t(y),
        name: (x, y) => x.name.localeCompare(y.name), size: (x, y) => y.size - x.size }[b.sort] || (() => 0);
      return J({ user: user.username, files: r.map(f => ({ ...f, created_at: new Date(f.created_at).toISOString(), size: Number(f.size) })).sort(s) });
    }
    if (a === 'init') {
      if (!(await limit('up:' + user.id, 60, 3600))) return E('Too many uploads.', 429);
      const name = String(b.name || '').slice(0, 200), ext = name.split('.').pop().toLowerCase();
      if (!OK[ext]) return E('File type is not supported.');
      if (!(b.size > 0) || b.size > MAX) return E('File is too large.');
      const key = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const r = await sql`insert into files(user_id,name,mime,object_key) values(${user.id},${name},${OK[ext]},${key}) returning id`;
      return J({ id: r[0].id, url: await putUrl(key, OK[ext]), mime: OK[ext] });
    }
    const f = b.id && /^[0-9a-f-]{36}$/i.test(b.id) && (await sql`select * from files where id=${b.id}::uuid and user_id=${user.id}`)[0];
    if (!f) return E('Not found.', 404);
    if (a === 'done') {
      try { const h = await head(f.object_key);
        if (h.ContentLength > MAX) throw 0;
        await sql`update files set status='ready',size=${h.ContentLength} where id=${f.id}`; return J({ ok: 1 });
      } catch { await remove(f.object_key).catch(() => {}); await sql`delete from files where id=${f.id}`; return E('File upload failed. Please try again.'); }
    }
    if (a === 'url') {
      if (!(await limit('dl:' + user.id, 120, 3600))) return E('Too many requests.', 429);
      return J({ url: await getUrl(f.object_key, f.name, !!b.dl) });
    }
    if (a === 'del') { await remove(f.object_key); await sql`delete from files where id=${f.id}`; return J({ ok: 1 }); }
    return E('Not found.', 404);
  } catch (e) { console.error(a, e); return E('Something went wrong. Please try again.', 500); }
}
